// FontScope Popup Script

document.addEventListener('DOMContentLoaded', function() {
  // Add any interactive functionality here
  console.log('FontScope popup loaded');
});
